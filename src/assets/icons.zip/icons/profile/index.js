import EmailIcon from "./email.svg";
import PhoneIcon from "./phone.svg";
import ProfileIcon from "./profile.svg";
import ProfileTickIcon from "./profile-tick.svg";
import ShieldIcon from "./shield-tick.svg";
import StaffDescIcon from "./staff-desc.svg";
import MapIcon from "./map.svg";
import CalendarIcon from "./calendar.svg";
import CalendarTickIcon from "./calendar-tick.svg";
import CalendarEditIcon from "./calendar-edit.svg";

export const iconMap = 22;

//   phone: <PhoneIcon />,
//   profile: <ProfileIcon />,
//   profileTick: <ProfileTickIcon />,
//   shieldTick: <ShieldIcon />,
//   staffDesc: <StaffDescIcon />,
//   map: <MapIcon />,
//   calendar: <CalendarIcon />,
//   calendarTick: <CalendarTickIcon />,
//   calendarEdit: <CalendarEditIcon />,
